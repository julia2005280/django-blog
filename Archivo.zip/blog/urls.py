from .views import HomeView, AboutView
from django.urls import path
from . import views

urlpatterns = [
    path('', views.PageListView.as_view(), name='page_list'),
    path('<int:pk>/', views.PageDetailView.as_view(), name='page_detail'),
]

from django.urls import path
from .views import PageListView, PageDetailView, AboutView

urlpatterns = [
    path('', PageListView.as_view(), name='page_list'),
    path('<int:pk>/', PageDetailView.as_view(), name='page_detail'),
    path('about/', AboutView.as_view(), name='about'),
]

from django.urls import path
from .views import PageListView, PageDetailView, PageCreateView, PageUpdateView, PageDeleteView

urlpatterns = [
    path('', PageListView.as_view(), name='page_list'),
    path('<int:pk>/', PageDetailView.as_view(), name='page_detail'),
    path('create/', PageCreateView.as_view(), name='page_create'),
    path('<int:pk>/edit/', PageUpdateView.as_view(), name='page_edit'),
    path('<int:pk>/delete/', PageDeleteView.as_view(), name='page_delete'),
    path('home/', HomeView.as_view(), name='home'),
    path('about/', AboutView.as_view(), name='about'),
]

