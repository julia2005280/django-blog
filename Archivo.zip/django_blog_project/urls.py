from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('allauth.urls')),
    path('pages/', include('blog.urls')),
    path('', lambda request: redirect('page_list')),  
]

from django.contrib import admin
from django.urls import path, include
from blog.views import HomeView

urlpatterns = [
    path('', HomeView.as_view(), name='home'),
    path('admin/', admin.site.urls),
    path('accounts/', include('accounts.urls')),
    path('pages/', include('blog.urls')),
    path('messages/', include('messenger.urls')),
]
